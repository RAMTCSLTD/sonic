import { useEffect, useRef } from 'react';
import * as Tone from 'tone';

interface VisualizerProps {
  analyser: Tone.Analyser;
  isPlaying: boolean;
}

const Visualizer = ({ analyser, isPlaying }: VisualizerProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);

  useEffect(() => {
    if (!analyser || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      animationRef.current = requestAnimationFrame(draw);

      const width = canvas.width;
      const height = canvas.height;
      
      // Clear with trail effect
      ctx.fillStyle = 'rgba(15, 15, 19, 0.2)';
      ctx.fillRect(0, 0, width, height);

      const values = analyser.getValue(); // Float32Array for FFT

      if (values instanceof Float32Array) {
        const barWidth = width / values.length;
        
        for (let i = 0; i < values.length; i++) {
            // values are in dB, usually -100 to 0. Normalize somewhat.
            // FFT data can be tricky, let's assume standard range
            const value = values[i]; 
            // Map -100db -> 0 height, 0db -> full height
            const percent = Math.max(0, (value + 100) / 100);
            
            const barHeight = percent * height * 1.5;
            
            // Gradient color
            const hue = (i / values.length) * 260 + 200; // Blues/Purples
            ctx.fillStyle = `hsl(${hue}, 70%, 60%)`;
            
            ctx.fillRect(i * barWidth, height - barHeight, barWidth - 1, barHeight);
        }
      }
    };

    if (isPlaying) {
      draw();
    } else {
        // Idle state animation
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#1a1a23';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#374151';
        ctx.font = "14px JetBrains Mono";
        ctx.textAlign = "center";
        ctx.fillText("VISUALIZER STANDBY", canvas.width/2, canvas.height/2);
        cancelAnimationFrame(animationRef.current);
    }

    return () => cancelAnimationFrame(animationRef.current);
  }, [analyser, isPlaying]);

  return (
    <canvas 
        ref={canvasRef} 
        width={600} 
        height={160} 
        className="w-full h-40 rounded-lg border border-slate-800 bg-synth-panel"
    />
  );
};

export default Visualizer;