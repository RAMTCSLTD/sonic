import { Heart, CreditCard, Download, X } from 'lucide-react';

interface PaywallProps {
  onContinue: () => void;
  onClose: () => void;
}

const Paywall = ({ onContinue, onClose }: PaywallProps) => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in duration-500">
      <div className="max-w-md w-full bg-[#1a1a23] border border-slate-700 rounded-2xl shadow-2xl p-8 text-center relative overflow-hidden">
        {/* Close Button */}
        <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-500 hover:text-white transition-colors p-1 rounded-full hover:bg-slate-800"
        >
            <X className="w-5 h-5" />
        </button>

        {/* Decorative Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent shadow-[0_0_20px_rgba(99,102,241,0.5)]"></div>
        
        <div className="w-16 h-16 bg-slate-800/50 rounded-full flex items-center justify-center mx-auto mb-6 border border-slate-700 shadow-inner">
          <Heart className="w-8 h-8 text-rose-500 fill-rose-500/20" />
        </div>
        
        <h2 className="text-2xl font-bold text-white mb-3 font-sans">Download Composition</h2>
        <p className="text-slate-400 mb-8 leading-relaxed text-sm">
          This download is available for free, but please consider a small donation of <strong>£0.59</strong> to keep the synth running.
        </p>
        
        <div className="space-y-4">
          <a 
            href="https://paypal.me/hejade/0.59GBP" 
            target="_blank" 
            rel="noopener noreferrer"
            className="group flex w-full items-center justify-center gap-3 py-3.5 px-4 bg-[#0070BA] hover:bg-[#005ea6] text-white font-semibold rounded-xl transition-all hover:scale-[1.02] active:scale-95 shadow-lg shadow-blue-900/20"
          >
            <CreditCard className="w-5 h-5" />
            <span>Donate £0.59 via PayPal</span>
          </a>
          
          <div className="relative py-2">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-800"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-[#1a1a23] px-2 text-slate-500 font-semibold tracking-wider">Or</span>
            </div>
          </div>

          <button 
            onClick={onContinue}
            className="flex w-full items-center justify-center gap-2 py-3 px-4 bg-slate-800/50 hover:bg-slate-800 text-slate-300 hover:text-white font-medium rounded-xl transition-colors text-sm border border-slate-700/50 hover:border-slate-600"
          >
            <Download className="w-4 h-4" />
            <span>Download for Free</span>
          </button>
        </div>
        
        <p className="mt-8 text-[10px] text-slate-600 uppercase tracking-widest">
          Optional Donation • Secure Payment
        </p>
      </div>
    </div>
  );
};

export default Paywall;