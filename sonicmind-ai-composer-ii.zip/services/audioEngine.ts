import * as Tone from 'tone';
import { Midi } from '@tonejs/midi';
import { Composition, TrackData } from '../types';

export class AudioEngine {
  private isInitialized = false;
  private isPlaying = false;
  private transport = Tone.Transport;
  private synths: Map<string, Tone.PolySynth> = new Map();
  private sequences: Tone.Part[] = [];
  private analyser: Tone.Analyser;
  private mainVol: Tone.Volume;
  private reverb: Tone.Reverb;
  private limiter: Tone.Limiter;

  constructor() {
    // Setup Master Chain
    this.limiter = new Tone.Limiter(-1).toDestination();
    this.reverb = new Tone.Reverb({ decay: 2.5, wet: 0.2 }).connect(this.limiter);
    this.mainVol = new Tone.Volume(-5).connect(this.reverb);
    this.analyser = new Tone.Analyser("fft", 256);
    this.mainVol.connect(this.analyser);
  }

  async initialize() {
    if (this.isInitialized) return;
    await Tone.start();
    this.isInitialized = true;
    console.log("Audio Engine Initialized");
  }

  stop() {
    this.transport.stop();
    this.sequences.forEach(seq => seq.dispose());
    this.sequences = [];
    this.transport.position = 0;
    this.isPlaying = false;
  }

  play() {
    if (this.transport.state === 'started') {
      this.transport.pause();
      this.isPlaying = false;
    } else {
      this.transport.start();
      this.isPlaying = true;
    }
    return this.isPlaying;
  }

  getAnalyser() {
    return this.analyser;
  }

  loadComposition(composition: Composition) {
    this.stop(); // Clear previous
    
    this.transport.bpm.value = composition.bpm;
    this.transport.timeSignature = 4;

    // Dispose old instruments
    this.synths.forEach(s => s.dispose());
    this.synths.clear();

    composition.tracks.forEach((track, index) => {
      // Create instrument and connect to main volume
      const synth = this.createInstrumentInstance(track.instrument);
      
      // Add effects if needed and connect to mainVol
      this.connectInstrumentToMix(synth, track.instrument, this.mainVol);

      this.synths.set(track.name + index, synth);

      const part = new Tone.Part((time, noteEvent) => {
        // Use PolySynth trigger for all instruments to safely handle overlaps
        synth.triggerAttackRelease(noteEvent.note, noteEvent.duration, time, noteEvent.velocity);
      }, track.notes).start(0);
      
      part.loop = true;
      part.loopEnd = "4m"; // Default loop length, AI usually writes 2-4 bars
      this.sequences.push(part);
    });
  }

  // --- Export Functions ---

  async exportMidi(composition: Composition): Promise<Blob> {
    const midi = new Midi();
    
    // Set Name
    midi.name = composition.title;

    // Set Tempo and Time Signature manually as setTempos might be missing or deprecated in the used version
    midi.header.tempos.push({
        bpm: composition.bpm,
        ticks: 0
    });
    
    midi.header.timeSignatures.push({ 
        timeSignature: [4, 4],
        ticks: 0,
        measures: 0
    });

    // Ensure Tone is ready for time conversion
    if (!this.isInitialized) await this.initialize();
    
    // Temporarily set BPM for accurate time conversion if not currently loaded
    const originalBpm = Tone.Transport.bpm.value;
    Tone.Transport.bpm.value = composition.bpm;

    composition.tracks.forEach(track => {
      const midiTrack = midi.addTrack();
      midiTrack.name = track.name;
      // Map simple instruments to MIDI instrument numbers (approximate)
      let instrumentNumber = 1; // Acoustic Grand Piano
      switch(track.instrument) {
        case 'bass': instrumentNumber = 33; break; // Electric Bass
        case 'pad': instrumentNumber = 89; break; // Pad 1 (new age)
        case 'synth': instrumentNumber = 81; break; // Lead 1 (square)
        case 'drums': instrumentNumber = 118; break; // Synth Drum
      }
      midiTrack.instrument.number = instrumentNumber;
      
      track.notes.forEach(note => {
         try {
             midiTrack.addNote({
               name: note.note,
               time: Tone.Time(note.time).toSeconds(),
               duration: Tone.Time(note.duration).toSeconds(),
               velocity: note.velocity
             });
         } catch (e) {
             console.warn("Skipping invalid note during MIDI export", note, e);
         }
      });
    });

    // Restore BPM
    Tone.Transport.bpm.value = originalBpm;

    return new Blob([midi.toArray()], { type: 'audio/midi' });
  }

  async exportWav(composition: Composition): Promise<Blob> {
    // Render 4 bars (assuming loop length)
    const measuresToRender = 4;
    const duration = Tone.Time(`${measuresToRender}m`).toSeconds();
    
    console.log("Starting Offline Render for duration:", duration);

    const buffer = await Tone.Offline(({ transport }) => {
        transport.bpm.value = composition.bpm;

        composition.tracks.forEach(track => {
            // Create isolated instrument for offline context
            const synth = this.createInstrumentInstance(track.instrument);
            
            // In offline context, we route to destination (which is the recorder)
            this.connectOfflineInstrument(synth, track.instrument);

            new Tone.Part((time, note) => {
               synth.triggerAttackRelease(note.note, note.duration, time, note.velocity);
            }, track.notes).start(0);
        });

        transport.start();
    }, duration);

    return this.bufferToWav(buffer);
  }

  // --- Helper Methods ---

  // Creates the synth instance - ALL instances are PolySynths to prevent collision errors
  private createInstrumentInstance(type: TrackData['instrument']): Tone.PolySynth {
    switch (type) {
      case 'bass':
        // PolySynth wrapping MonoSynth allows for chords/overlaps without crashing
        return new Tone.PolySynth(Tone.MonoSynth, {
          oscillator: { type: "sawtooth" },
          envelope: { attack: 0.05, decay: 0.2, sustain: 0.4, release: 0.8 },
          filterEnvelope: { attack: 0.001, decay: 0.1, sustain: 0.1, baseFrequency: 200, octaves: 2.6 }
        });
      case 'drums':
        // PolySynth wrapping MembraneSynth allows Kick+Snare at same timestamp
        return new Tone.PolySynth(Tone.MembraneSynth, {
            pitchDecay: 0.05,
            octaves: 4,
            oscillator: { type: 'sine' },
            envelope: { attack: 0.001, decay: 0.4, sustain: 0.01, release: 1.4 }
        });
      case 'pad':
        const pad = new Tone.PolySynth(Tone.Synth, {
          oscillator: { type: "fatsawtooth" },
          envelope: { attack: 0.5, decay: 0.3, sustain: 0.8, release: 2.5 }
        });
        pad.volume.value = -8;
        return pad;
      case 'synth':
      default:
        return new Tone.PolySynth(Tone.Synth, {
          oscillator: { type: "triangle" },
          envelope: { attack: 0.02, decay: 0.1, sustain: 0.3, release: 1 }
        });
    }
  }

  // Connects instrument to the live mix (with effects)
  private connectInstrumentToMix(instrument: Tone.Instrument<any>, type: string, destination: Tone.ToneAudioNode) {
    if (type === 'drums') {
        const crusher = new Tone.BitCrusher(4);
        instrument.connect(crusher);
        crusher.connect(destination);
    } else if (type === 'synth') {
        const feedbackDelay = new Tone.FeedbackDelay("8n.", 0.3);
        instrument.connect(feedbackDelay);
        feedbackDelay.connect(destination);
    } else {
        instrument.connect(destination);
    }
  }

  // Connects instrument to the offline destination (simplified chain)
  private connectOfflineInstrument(instrument: Tone.Instrument<any>, type: string) {
      // In Tone.Offline, toDestination() routes to the offline buffer
      if (type === 'drums') {
          const crusher = new Tone.BitCrusher(4).toDestination();
          instrument.connect(crusher);
      } else if (type === 'synth') {
          const feedbackDelay = new Tone.FeedbackDelay("8n.", 0.3).toDestination();
          instrument.connect(feedbackDelay);
      } else {
          instrument.toDestination();
      }
  }

  // Simple WAV Encoder
  private bufferToWav(buffer: Tone.ToneAudioBuffer | AudioBuffer): Blob {
    // Convert to standard AudioBuffer if it's a Tone wrapper
    const audioBuffer = (buffer instanceof Tone.ToneAudioBuffer) ? buffer.get() : buffer;
    
    const numOfChan = audioBuffer.numberOfChannels;
    const length = audioBuffer.length * numOfChan * 2 + 44;
    const outBuffer = new ArrayBuffer(length);
    const view = new DataView(outBuffer);
    const channels = [];
    let i;
    let sample;
    let offset = 0;
    let pos = 0;

    // write WAVE header
    setUint32(0x46464952);                         // "RIFF"
    setUint32(length - 8);                         // file length - 8
    setUint32(0x45564157);                         // "WAVE"

    setUint32(0x20746d66);                         // "fmt " chunk
    setUint32(16);                                 // length = 16
    setUint16(1);                                  // PCM (uncompressed)
    setUint16(numOfChan);
    setUint32(audioBuffer.sampleRate);
    setUint32(audioBuffer.sampleRate * 2 * numOfChan); // avg. bytes/sec
    setUint16(numOfChan * 2);                      // block-align
    setUint16(16);                                 // 16-bit (hardcoded in this example)

    setUint32(0x61746164);                         // "data" - chunk
    setUint32(length - pos - 4);                   // chunk length

    // write interleaved data
    for(i = 0; i < audioBuffer.numberOfChannels; i++)
      channels.push(audioBuffer.getChannelData(i));

    while(pos < audioBuffer.length) {
      for(i = 0; i < numOfChan; i++) {             // interleave channels
        sample = Math.max(-1, Math.min(1, channels[i][pos])); // clamp
        sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767)|0; // scale to 16-bit signed int
        view.setInt16(44 + offset, sample, true);          // write 16-bit sample
        offset += 2;
      }
      pos++;
    }

    function setUint16(data: number) {
      view.setUint16(pos, data, true);
      pos += 2;
    }
    function setUint32(data: number) {
      view.setUint32(pos, data, true);
      pos += 4;
    }

    return new Blob([outBuffer], {type: "audio/wav"});
  }
}

export const audioEngine = new AudioEngine();