import { GoogleGenAI, Type } from "@google/genai";
import { Composition } from "../types";

const SYSTEM_INSTRUCTION = `
You are an expert music composer and producer AI. Your goal is to generate musical compositions in a JSON format that can be played by a web synthesizers.

When given a prompt (mood, genre, description):
1. Analyze the request to determine BPM, Scale, and Instrument choices.
2. Compose distinct tracks:
   - 'synth': Melody or lead lines (higher octave).
   - 'bass': Basslines (lower octave).
   - 'drums': Rhythmic patterns (use specific mapping: C2=Kick, D2=Snare, F#2=HiHat).
   - 'pad': Atmospheric chords.
3. Use 'time' in "Bar:Quarter:Sixteenth" format (e.g., "0:0:0", "0:1:0").
4. Use 'duration' in notation format (e.g., "4n" = quarter, "8n" = eighth, "1m" = whole measure).
5. Keep the composition loopable, typically 2 to 4 bars long.
6. Be creative with harmony and rhythm.
`;

const compositionSchema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "A creative title for the track" },
    bpm: { type: Type.NUMBER, description: "Beats per minute (60-180)" },
    scale: { type: Type.STRING, description: "Musical key/scale (e.g., C Minor)" },
    mood: { type: Type.STRING, description: "One or two words describing the vibe" },
    description: { type: Type.STRING, description: "Short analysis of what was composed" },
    tracks: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          instrument: { type: Type.STRING, enum: ["synth", "bass", "drums", "pad"] },
          color: { type: Type.STRING, description: "Hex color code for UI visualization" },
          notes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                note: { type: Type.STRING, description: "Note name with octave (e.g., C4)" },
                duration: { type: Type.STRING, description: "Tone.js duration (e.g., 4n, 8n)" },
                time: { type: Type.STRING, description: "Bar:Quarter:Sixteenth (e.g., 0:0:0)" },
                velocity: { type: Type.NUMBER, description: "0.0 to 1.0" }
              },
              required: ["note", "duration", "time", "velocity"]
            }
          }
        },
        required: ["name", "instrument", "notes", "color"]
      }
    }
  },
  required: ["title", "bpm", "scale", "tracks", "mood", "description"]
};

export class GeminiMusicService {
  private ai: GoogleGenAI;

  constructor() {
    const apiKey = process.env.API_KEY || '';
    this.ai = new GoogleGenAI({ apiKey });
  }

  async generateComposition(prompt: string): Promise<Composition> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          responseMimeType: "application/json",
          responseSchema: compositionSchema,
          temperature: 0.7, // Slight creativity
        },
      });

      const text = response.text;
      if (!text) throw new Error("No response from Gemini");
      
      return JSON.parse(text) as Composition;
    } catch (error) {
      console.error("Gemini Generation Error:", error);
      throw error;
    }
  }
}